function updateTimer(timer) {
  document.querySelector('.timer-display').textContent = timer;
}

function sendMessage(command, duration) {
  browser.runtime.sendMessage({ command: command, duration: duration });
}

document.querySelector('.start-button').addEventListener('click', () => {
  sendMessage("start", 30);
});

document.querySelector('.stop-button').addEventListener('click', () => {
  sendMessage("stop");
});

browser.runtime.onMessage.addListener((message) => {
  if (message.timer) {
    updateTimer(message.timer);
  }
});
