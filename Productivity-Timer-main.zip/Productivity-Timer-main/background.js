let timer;
let timeLeft;
let isRunning = false;

function startTimer(duration) {
  let start = Date.now();
  timeLeft = duration * 1000;
  timer = setInterval(() => {
    let delta = Date.now() - start;
    timeLeft = Math.max(duration * 1000 - delta, 0);
    updateTimer();
    if (timeLeft <= 0) {
      clearInterval(timer);
      showNotification();
    }
  }, 1000);
}

function stopTimer() {
  clearInterval(timer);
  isRunning = false;
  updateTimer();
}

function updateTimer() {
  let minutes = Math.floor(timeLeft / 60000);
  let seconds = Math.floor((timeLeft % 60000) / 1000);
  let display = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  browser.runtime.sendMessage({ timer: display });
  if (isRunning) {
    browser.browserAction.disable();
  } else {
    browser.browserAction.enable();
  }
}

function showNotification() {
  browser.notifications.create({
    type: "basic",
    title: "Time's up!",
    message: "Your productivity timer has ended.",
    iconUrl: "icons/icon96.png"
  });
}

browser.runtime.onMessage.addListener((message) => {
  if (message.command === "start") {
    if (!isRunning) {
      startTimer(message.duration);
      isRunning = true;
      updateTimer();
    }
  } else if (message.command === "stop") {
    if (isRunning) {
      stopTimer();
      updateTimer();
    }
  }
});
