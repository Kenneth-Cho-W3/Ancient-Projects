# Attribution

The icon image is sourced from Flaticon.com, a platform that offers a vast collection of free and premium icons for designers and developers worldwide.

[Source](https://www.flaticon.com/free-icon/schedule_3652191?term=time&page=1&position=24&origin=search&related_id=3652191)