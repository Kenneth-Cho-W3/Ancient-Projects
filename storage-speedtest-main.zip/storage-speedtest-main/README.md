# Storage Speedtest

Storage Speedtest is a Python script that measures the write and read speeds of a disk volume. It creates a binary file with a specified size on the given volume, measures the time it takes to write the file, and calculates the write speed in megabytes per second. Then the script reads the same file, measures the time it takes to read the file, and calculates the read speed in megabytes per second. Finally, the script deletes the test file.

## Dependencies
- Python 3.6 or later 

## Installation

1. Clone the repository or download the speedtest.py file.
2. Make sure Python 3 is installed on your system.
3. Open a terminal or command prompt and navigate to the directory containing `speedtest.py`.

## Usage

The script takes two command-line arguments: the path to the volume to be tested and the file size in megabytes. To run the script, type the following command in the terminal or command prompt:

```powershell
python speedtest.py [volume path] [file size in MB]
```

Replace `[volume path]` with the path to the volume you want to test, and replace `[file size in MB]` with the size of the test file in megabytes. For example:

```powershell
python speedtest.py /mnt/data 1024
```

This command tests the write and read speeds of the volume at `/mnt/data` using a test file of 1024 megabytes.

## License

This project is licensed under the Mozilla Public License. See the `LICENSE` file for details.
