import os
import subprocess
import sys
import time

def write_speed_test(volume_path, filename, filesize):
    filepath = os.path.join(volume_path, filename)
    start_time = time.time()
    with open(filepath, 'wb') as f:
        f.write(os.urandom(filesize))
    end_time = time.time()
    write_speed = (filesize / (end_time - start_time)) / 1000000
    print(f"Write speed: {write_speed} MB/s")

def read_speed_test(volume_path, filename):
    filepath = os.path.join(volume_path, filename)
    start_time = time.time()
    with open(filepath, 'rb') as f:
        f.read()
    end_time = time.time()
    filesize = os.path.getsize(filepath)
    read_speed = (filesize / (end_time - start_time)) / 1000000
    print(f"Read speed: {read_speed} MB/s")

if __name__ == '__main__':
    if len(sys.argv) < 3:
        print("Usage: python speedtest.py [volume path] [file size in MB]")
        sys.exit(1)
    volume_path = sys.argv[1]
    filesize = int(sys.argv[2]) * 1024 * 1024 # Convert from MB to bytes
    filename = 'testfile.bin'
    write_speed_test(volume_path, filename, filesize)
    read_speed_test(volume_path, filename)
    subprocess.call(['rm', '-f', os.path.join(volume_path, filename)])
