# Vibrance-XVB
A cryptocurrency built on top of Polygon Network, providing lightning-fast transaction speeds.
