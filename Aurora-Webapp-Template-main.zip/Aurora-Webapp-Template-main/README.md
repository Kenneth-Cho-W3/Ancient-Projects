# Aurora-Webapp-Template
Aurora is a simple Android Webapp Template written in Kotlin. You can just change the URL to the website you want, and everything will be ready.  

Get started by downloading the full source code from the official website  
[https://aurora-android.netlify.app/](https://aurora-android.netlify.app/)
