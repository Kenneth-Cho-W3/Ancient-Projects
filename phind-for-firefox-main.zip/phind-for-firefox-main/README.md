# Phind Search Firefox Add-On
## Description

The Phind Search Firefox Add-On sets phind.com as the default search engine in Firefox. This add-on provides users with the ability to easily search phind.com directly from the Firefox search bar.
## Installation

To install the Phind Search Firefox Add-On, follow these steps:

1. Open your Firefox web browser and go to https://addons.mozilla.org/zh-TW/firefox/addon/phind-search/.
2. On the Phind Search add-on page, click the "Add to Firefox" button to start the installation process.
3. A pop-up window will appear asking you to confirm the installation. Click "Add" to proceed.
4. Once the installation is complete, you will be prompted to restart Firefox to complete the process. Click "Restart now" to do so.
5. After Firefox restarts, the Phind Search add-on will be installed and ready to use.
6. To access the Phind Search add-on, click on the three horizontal lines (also known as the "hamburger menu") in the top-right corner of the Firefox window and select "Add-ons" from the menu.
7. In the Add-ons Manager, you should see the Phind Search add-on listed. If it's not enabled, click the toggle switch to turn it on.
8. To use the Phind Search add-on, simply type a search term in the Firefox search bar and hit enter. Phind Search will display relevant results from multiple search engines on a single page.
9. You can configure the settings for the Phind Search add-on by clicking the "Preferences" button next to it in the Add-ons Manager. From there, you can customize the search engines used and the appearance of the search results page.

Once the add-on is installed, you should see Phind as the default search engine in the Firefox search bar.
## Contributing

If you'd like to contribute to the development of the Phind Search Firefox Add-On, feel free to create a fork of the project and submit a pull request with your changes. Please make sure to follow the existing code style and submit unit tests with any new functionality.
## License

This project is licensed under the Mozilla Public License. See the `LICENSE` file for details.
