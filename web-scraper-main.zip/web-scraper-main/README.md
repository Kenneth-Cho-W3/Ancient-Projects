# Web Scraping Tool

This is a command-line tool for web scraping that allows you to extract information from websites and save it in a CSV file. The tool takes a URL as input, scrapes the data, and saves it in a CSV file with a timestamp.
## Installation

To use this tool, you will need to have Python 3 installed on your machine. You can download Python 3 from the official website: https://www.python.org/downloads/.

You will also need to install the following packages:

```powershell
pip install pandas
pip install beautifulsoup4
pip install requests
```

## Usage

To use the tool, open a command prompt or terminal and navigate to the directory where the main.py file is located. Then, run the following command:

```powershell
python main.py <URL>
```
Replace <URL> with the URL of the website you want to scrape. For example:

```powershell
python main.py https://example.com
```
  
The tool will scrape the website and save the data in a CSV file in a subfolder with the name of the website. The CSV file will be named `data_<timestamp>.csv`, where `<timestamp>` is the date and time when the data was scraped.
## License

This project is licensed under the Mozilla Public License. See the LICENSE file for details.
