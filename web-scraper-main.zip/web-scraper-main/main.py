import requests
from bs4 import BeautifulSoup
import pandas as pd
import os
import argparse
import datetime

def scrape_website(url):
    # Make a GET request to the URL
    response = requests.get(url)

    # Create a BeautifulSoup object and parse the HTML content
    soup = BeautifulSoup(response.content, 'html.parser')

    # Find all <a> tags with 'href' attribute
    links = soup.find_all('a', href=True)

    # Extract the href attribute of each <a> tag and return as a list of tuples
    links_list = [(link.text, link['href']) for link in links]

    return links_list

def save_data(data, website_name):
    # Get the current date and time
    now = datetime.datetime.now()

    # Create a folder with the website name if it doesn't exist
    if not os.path.exists(website_name):
        os.makedirs(website_name)

    # Create the filename with the current date and time
    filename = f"{website_name}/data_{now.strftime('%Y-%m-%d %H-%M-%S')}.csv"

    # Check if the file already exists
    if os.path.isfile(filename):
        # If it exists, read the existing CSV data and append new data to it
        df = pd.read_csv(filename)
        df = df.append(pd.DataFrame(data, columns=['Link Text', 'URL']), ignore_index=True)
    else:
        # If it doesn't exist, create a new CSV file with the data
        df = pd.DataFrame(data, columns=['Link Text', 'URL'])

    # Save the data to the CSV file
    df.to_csv(filename, index=False)

def main():
    parser = argparse.ArgumentParser(description='Scrape links from a website.')
    parser.add_argument('url', type=str, help='The URL to scrape.')
    args = parser.parse_args()

    # Extract the website name from the URL
    website_name = args.url.split('//')[1].split('/')[0]

    # Scrape the website for links
    print(f"{datetime.datetime.now()} - Scraping {args.url}")
    data = scrape_website(args.url)

    # Save the data to a CSV file
    save_data(data, website_name)
    print(f"{datetime.datetime.now()} - Data saved to {website_name}/")

if __name__ == '__main__':
    main()
