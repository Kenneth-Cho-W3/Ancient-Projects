# Quadratic Equation Grapher

This program prompts the user to enter the coefficients of a quadratic equation in standard form `(ax^2 + bx + c = 0)` and calculates the real solutions (if any) using the quadratic formula. It then generates a graph of the equation using the luagraph library and saves it as a JPEG image. The program also saves the input coefficients and solutions as a JSON file.
Requirements

- Lua 5.1 or later
- luagraph and json libraries

## Usage

1. Open a terminal or command prompt.
2. Navigate to the directory where the quadratic.lua file is located.
3. Run the program by entering the command lua quadratic.lua.
4. Follow the prompts to enter the coefficients of the quadratic equation.
5. The program will generate a graph of the equation and save it as a JPEG image named graph.jpg.
6. The program will also save the input coefficients and solutions as a JSON file named results.json.
7. The program will ask if you want to quit or continue. Enter `Y` or `y` to quit, or any other key to continue.

## Notes

- If the discriminant `(b^2 - 4ac)` of the quadratic equation is negative, the program will report that there are no real solutions.
- If the discriminant is zero, the program will report that there is one real solution.
- If the discriminant is positive, the program will report that there are two real solutions.
- The program uses a default range of `x` values from `-10` to `10` with a step size of `0.1` to generate the data points for the graph. You can adjust these values by changing the `x_min`, `x_max`, and `x_step` variables in the program.
- The program saves the graph as a JPEG image by default. You can change the output format to PNG by changing the `g:set_output_format("jpg")` line to `g:set_output_format("png")`.
- You can change the name of the output file for the graph by changing the `g:set_output_file("graph.jpg")` line to a different file name.
- You can customize the title and axis labels for the graph by modifying the `g:set_title("Quadratic Equation Graph")` and `g:set_axis_labels("x", "f(x)")` lines, respectively.

## License

This program is licensed under the Mozilla Public License. See the LICENSE file for more information.
