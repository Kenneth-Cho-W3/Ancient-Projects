---@diagnostic disable: need-check-nil
-- Load the required libraries
local json = require("json")
local graph = require("luagraph")

-- Define a function to calculate the discriminant
function calculate_discriminant(coefficient_a, coefficient_b, coefficient_c)
   return coefficient_b^2 - 4*coefficient_a*coefficient_c
end

-- Define a function to calculate the solutions
function calculate_solutions(coefficient_a, coefficient_b, coefficient_c)
   local discriminant = calculate_discriminant(coefficient_a, coefficient_b, coefficient_c)

   if discriminant < 0 then
      -- No real solutions
      return nil
   elseif discriminant == 0 then
      -- One real solution
      return -coefficient_b / (2*coefficient_a)
   else
      -- Two real solutions
      local solution_1 = (-coefficient_b + math.sqrt(discriminant)) / (2*coefficient_a)
      local solution_2 = (-coefficient_b - math.sqrt(discriminant)) / (2*coefficient_a)
      return solution_1, solution_2
   end
end

-- Define a function to prompt the user for input
function get_coefficients()
   io.write("Enter the value of coefficient a: ")
   local coefficient_a = tonumber(io.read("*n"))

   io.write("Enter the value of coefficient b: ")
   local coefficient_b = tonumber(io.read("*n"))

   io.write("Enter the value of coefficient c: ")
   local coefficient_c = tonumber(io.read("*n"))

   return coefficient_a, coefficient_b, coefficient_c
end

-- Define a function to save the results as a JSON file
function save_results_as_json(filename, results)
   local file = io.open(filename, "w")
   file:write(json.encode(results))
   file:close()
end

-- Main program loop
while true do
   -- Prompt the user for input
   local coefficient_a, coefficient_b, coefficient_c = get_coefficients()

   -- Calculate the solutions
   local solutions = calculate_solutions(coefficient_a, coefficient_b, coefficient_c)

   -- Generate the data points for the graph
   local x_min = -10
   local x_max = 10
   local x_step = 0.1
   local x = {}
   local y = {}

   for i = x_min, x_max, x_step do
      table.insert(x, i)
      table.insert(y, coefficient_a*i^2 + coefficient_b*i + coefficient_c)
   end

   -- Create the graph object
   local g = graph.new()

   -- Add the data points to the graph object
   local series = g:add_series("f(x)")
   series:set(x, y)

   -- Set the x and y axis labels
   g:set_axis_labels("x", "f(x)")

   -- Set the title of the graph
   g:set_title("Quadratic Equation Graph")

   -- Set the output format of the graph (JPG or PNG)
   g:set_output_format("jpg") -- Change to "png" if you prefer PNG format

   -- Set the output file name of the graph
   g:set_output_file("graph.jpg") -- Change the file name as desired

   -- Generate the graph
   g:draw()



   -- Save the results as a JSON file
   local results = {
      ["coefficient_a"] = coefficient_a,
      ["coefficient_b"] = coefficient_b,
      ["coefficient_c"] = coefficient_c,
      ["solutions"] = solutions
   }
   save_results_as_json("results.json", results)

   -- Ask the user if they want to quit or continue
   io.write("Do you want to quit? (Y/N) ")
   local answer = io.read()

   if answer == "Y" or answer == "y" then
      break
   end
end
