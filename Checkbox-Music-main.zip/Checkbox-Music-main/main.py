import sys
import os
import time
import threading
from tkinter import messagebox
import csv
from PyQt5.QtGui import QFont, QIcon
from PyQt5.QtCore import QUrl
from PyQt5.QtMultimedia import QMediaContent, QMediaPlayer
from PyQt5.QtWidgets import (
    QApplication,
    QCheckBox,
    QFileDialog,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QPushButton,
    QVBoxLayout,
    QWidget,
    QFileDialog,
    QSpinBox, 
)

class BeatMaker(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Checkbox Music")
        self.samples_dir = "samples"
        self.sounds = self.get_sample_files()
        self.players = [QMediaPlayer() for i in range(len(self.sounds))]
        self.create_widgets()

        startup_sound = "system/startup_notification.wav"
        self.startup_player = QMediaPlayer()
        self.startup_player.setMedia(QMediaContent(QUrl.fromLocalFile(startup_sound)))
        self.startup_player.play()


    def get_sample_files(self):
        sound_files = []
        for file_name in os.listdir(self.samples_dir):
            if file_name.endswith(".wav") or file_name.endswith(".mp3"):
                sound_files.append(os.path.join(self.samples_dir, file_name))
        return sound_files

    def create_widgets(self):
        widget = QWidget()
        self.setCentralWidget(widget)

        layout = QVBoxLayout()
        widget.setLayout(layout)

        # Set window icon
        icon_path = "icons/icon.png"
        icon = QIcon(icon_path)
        self.setWindowIcon(icon)

        # Add play button layout
        play_export_layout = QHBoxLayout()
        layout.insertLayout(0, play_export_layout)

        self.play_button = QPushButton("Play")
        poppins = QFont("Poppins")
        self.play_button.setFont(poppins)
        self.play_button.clicked.connect(self.play_beat)
        play_export_layout.addWidget(self.play_button)

        # Add grid layout for checkboxes
        grid_layout = QGridLayout()
        layout.addLayout(grid_layout)

        self.check_boxes = []
        for s, sound in enumerate(self.sounds):
            label = QLabel(os.path.basename(sound))
            label.setFont(poppins)
            grid_layout.addWidget(label, s + 1, 0)
            column = []
            for b in range(16):
                check_box = QCheckBox()
                column.append(check_box)
                grid_layout.addWidget(check_box, s + 1, b + 1)
            self.check_boxes.append(column)

        # Add BPM spin box and confirm button layout
        bpm_layout = QHBoxLayout()
        layout.addLayout(bpm_layout)

        self.bpm_label = QLabel("BPM:")
        self.bpm_label.setFont(poppins)
        bpm_layout.addWidget(self.bpm_label)

        self.bpm_spin_box = QSpinBox()
        self.bpm_spin_box.setRange(20, 300)
        self.bpm_spin_box.setValue(120)
        self.bpm_spin_box.setFont(poppins)
        bpm_layout.addWidget(self.bpm_spin_box)

        self.confirm_button = QPushButton("Confirm")
        self.confirm_button.setFont(poppins)
        self.confirm_button.clicked.connect(self.set_bpm)
        bpm_layout.addWidget(self.confirm_button)

        # Add bottom button layout
        bottom_layout = QHBoxLayout()
        layout.addLayout(bottom_layout)

        self.save_button = QPushButton("Save")
        self.save_button.setFont(poppins)
        self.save_button.clicked.connect(self.save_beat)
        bottom_layout.addWidget(self.save_button)

        self.load_button = QPushButton("Load")
        self.load_button.setFont(poppins)
        self.load_button.clicked.connect(self.load_beat)
        bottom_layout.addWidget(self.load_button)

        self.info_button = QPushButton("Info")
        self.info_button.setFont(poppins)
        self.info_button.clicked.connect(self.open_info)
        bottom_layout.addWidget(self.info_button)

        self.exit_button = QPushButton("Exit")
        self.exit_button.setFont(poppins)
        self.exit_button.clicked.connect(self.exit_app)
        bottom_layout.addWidget(self.exit_button)



    def save_beat(self):
        options = QFileDialog.Options()
        file_name, _ = QFileDialog.getSaveFileName(self, "Save Beat Pattern", "", "CSV Files (*.csv)", options=options)
        if file_name:
            beat_pattern = []
            for sound_index, sound_file in enumerate(self.sounds):
                beat_column = [os.path.basename(sound_file)]
                for beat_index in range(16):
                    beat_column.append(str(int(self.check_boxes[sound_index][beat_index].isChecked())))
                beat_pattern.append(beat_column)
            with open(file_name, "w", newline='') as f:
                writer = csv.writer(f)
                writer.writerows(beat_pattern)

    def load_beat(self):
        options = QFileDialog.Options()
        file_name, _ = QFileDialog.getOpenFileName(self, "Load Beat Pattern", "", "CSV Files (*.csv)", options=options)
        if file_name:
            try:
                with open(file_name, "r") as f:
                    reader = csv.reader(f)
                    beat_pattern = list(reader)
                    grid_layout = self.centralWidget().layout().itemAt(1).layout()  # get the grid layout
                    for sound_index, sound_file in enumerate(self.sounds):
                        sound_label = QLabel(os.path.basename(sound_file))
                        sound_label.setFont(QFont("Poppins"))
                        grid_layout.addWidget(sound_label, sound_index, 0)  # use the grid_layout variable
                        for beat_index in range(16):
                            beat_checkbox = QCheckBox()
                            beat_checkbox.setChecked(int(beat_pattern[sound_index][beat_index+1]))
                            grid_layout.addWidget(beat_checkbox, sound_index, beat_index + 1)  # use the grid_layout variable
                            self.check_boxes[sound_index].append(beat_checkbox)
                            checkbox_sound_file = beat_pattern[sound_index][0]
                            if checkbox_sound_file != os.path.basename(sound_file):
                                print("Sound file name does not match checkbox name")
                                break
            except FileNotFoundError:
                print("No saved beat pattern found.")

    def set_bpm(self):
        self.bpm = self.bpm_spin_box.value()

    def play_beat(self):
        if self.bpm is not None and self.bpm > 0:
            interval = 60 / self.bpm # calculate interval between beats
            while True:
                for sound_index, sound_file in enumerate(self.sounds):
                    column = self.check_boxes[sound_index]
                    if any([column[i].isChecked() for i in range(len(column))]): # if any checkbox in the column is checked
                        self.players[sound_index].setMedia(QMediaContent(QUrl.fromLocalFile(sound_file)))
                        self.players[sound_index].play()
                time.sleep(interval)


    def on_play_clicked(play_beat):
        global play_thread
        if play_thread and play_thread.is_alive():
            messagebox.showerror("Error", "Already playing!")
            return
        play_thread = threading.Thread(target=play_beat)
        play_thread.start()

    def open_info(self):
        os.system('python info.py')

    def exit_app(self):
        sys.exit()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    beat_maker = BeatMaker()
    beat_maker.show()
    sys.exit(app.exec_())