# Checkbox Music App
![Screenshot](https://www.linkpicture.com/q/Screenshot-2023-04-22-124210.png)

The Checkbox Music App is a simple beat maker that allows you to create and play your own music patterns. You can choose from a variety of sound samples, and then create beats by selecting checkboxes on a grid. You can then play your beat, save it, or load it later.
## Installation

1. Install Python 3.x from the official website https://www.python.org/downloads/
2. Install PyQt5 by running pip install PyQt5 in the command line
3. Download the Checkbox Music App files from GitHub and extract them to a directory on your computer.

## How to Use

1. Run the main.py file by double-clicking it or by typing python main.py in the command line.
2. The Checkbox Music App window will appear.
3. To play a sound, select the checkboxes on the grid for the corresponding sound you want to play. You can select as many checkboxes as you like for each sound.
4. Click the Play button to hear your beat.
5. You can adjust the tempo of your beat by changing the BPM spin box value and clicking the Confirm button.
6. You can save your beat by clicking the Save button and choosing a file name and location.
7. You can load a saved beat by clicking the Load button and selecting the saved CSV file.
8. To exit the app, click the Exit button.

## Troubleshooting

- If you encounter any issues while using the app, please report them on the app's GitHub page.
- Please make sure you have the latest version of Python and PyQt5 installed.
- If you experience any audio issues, please make sure your speakers or headphones are properly connected and working.
