import sys
from PyQt5.QtWidgets import QApplication, QLabel, QMainWindow, QVBoxLayout, QWidget
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont

# Create application object
app = QApplication(sys.argv)

# Create main window object
main_window = QMainWindow()
main_window.resize(1000, 750)
main_window.setWindowTitle("App Info")

# Create label with program description
program_description = """This is a Python program designed as a beat maker application. It uses the PyQt5 library for its GUI interface and allows users to:

- create beat patterns
- play the created beat patterns
- save the created beat patterns
- load previously saved beat patterns

The program provides the user with checkboxes to make a beat pattern and buttons for other functionalities mentioned above. The sounds used in the beat patterns include kick, snare, clap, and hihat.

The beats can be exported in MP3 format and saved patterns can be stored as a pickle file.

Please note, this program is currently in beta testing. It is still being developed and improved, but is available for use."""

program_label = QLabel(program_description)
program_label.setAlignment(Qt.AlignLeft)
program_label.setWordWrap(True)

# Set font for program label
font = QFont("Poppins")
program_label.setFont(font)

# Create layout for main window
layout = QVBoxLayout()
layout.addWidget(program_label)

# Set central widget for main window
central_widget = QWidget()
central_widget.setLayout(layout)
main_window.setCentralWidget(central_widget)

# Show main window and run application
main_window.show()
sys.exit(app.exec_())
