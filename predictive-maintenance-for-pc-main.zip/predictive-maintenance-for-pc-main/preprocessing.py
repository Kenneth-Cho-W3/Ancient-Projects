import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler

# Load the historical data from the CSV file
data = pd.read_csv('data/historical_data.csv')

# Extract the features and target variable
features = data[['cpu_percent', 'disk_usage', 'memory_percent']]
target = data['target']

# Normalize the features using MinMaxScaler
scaler = MinMaxScaler()
features_scaled = scaler.fit_transform(features)

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(features_scaled, target, test_size=0.2, random_state=42)

# Create a new DataFrame with the preprocessed data
preprocessed_data = pd.DataFrame(data=features_scaled, columns=['cpu_percent', 'disk_usage', 'memory_percent'])
preprocessed_data['target'] = target

# Write the preprocessed data to a CSV file
preprocessed_data.to_csv('data/preprocessed_data.csv', index=False)
