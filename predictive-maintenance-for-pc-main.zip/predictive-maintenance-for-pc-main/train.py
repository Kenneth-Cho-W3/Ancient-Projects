import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler
from sklearn.ensemble import RandomForestClassifier
import psutil
import warnings

# Load the preprocessed data from the CSV file
data = pd.read_csv('data/preprocessed_data.csv')

# Extract the features and target variable
features = data[['cpu_percent', 'disk_usage', 'memory_percent']]
target = data['target']

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(features, target, test_size=0.2, random_state=42)

# Normalize the features using MinMaxScaler
scaler = MinMaxScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Train a Random Forest classifier on the preprocessed data
clf = RandomForestClassifier(random_state=42)
clf.fit(X_train_scaled, y_train)

# Evaluate the model on the testing set
accuracy = clf.score(X_test_scaled, y_test)
print(f"Model accuracy on testing set: {accuracy:.2f}")

# Get the current PC situation and preprocess the data
cpu_percent = psutil.cpu_percent()
disk_usage = psutil.disk_usage('/').percent
memory_percent = psutil.virtual_memory().percent
current_situation = [[cpu_percent, disk_usage, memory_percent]]
current_situation_scaled = scaler.transform(current_situation)

# Make a prediction for the current PC situation
with warnings.catch_warnings():
    warnings.simplefilter("ignore")
    predicted_target = clf.predict(current_situation_scaled)[0]
print(f"Prediction for current PC situation: {predicted_target}")
