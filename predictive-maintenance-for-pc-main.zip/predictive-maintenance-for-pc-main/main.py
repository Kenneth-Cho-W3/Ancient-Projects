import joblib
import os
import psutil
import time
import argparse
import smtplib
from email.mime.text import MIMEText
import pandas as pd

model_path = os.path.join(os.getcwd(), 'model/model.pkl')
model = joblib.load(model_path)


def check_cpu_usage(threshold):
    usage = psutil.cpu_percent()
    return usage > threshold

def check_disk_usage(threshold):
    total, used, free = psutil.disk_usage("/")
    return (free / total) * 100 < threshold

def check_memory_usage(threshold):
    usage = psutil.virtual_memory().percent
    return usage > threshold

def send_email(subject, message, sender_email, receiver_email, password):
    msg = MIMEText(message)
    msg['Subject'] = subject
    msg['From'] = sender_email
    msg['To'] = receiver_email

    server = smtplib.SMTP('smtp.gmail.com', 587)
    server.starttls()
    server.login(sender_email, password)
    server.sendmail(sender_email, receiver_email, msg.as_string())
    server.quit()

def collect_data():
    cpu_usage = psutil.cpu_percent()
    disk_usage = (psutil.disk_usage("/").free / psutil.disk_usage("/").total) * 100
    memory_usage = psutil.virtual_memory().percent
    data = {"CPU": [cpu_usage], "Disk": [disk_usage], "Memory": [memory_usage]}
    df = pd.DataFrame(data)
    return df

def preprocess_data(df):
    # Load saved scaler
    scaler = joblib.load('model/scaler.pkl')

    # Scale the data
    scaled_data = scaler.transform(df)

    return scaled_data

def load_model():
    # Load saved model
    model = joblib.load('model/model.pkl')
    return model

def predict_failure(scaled_data):
    model = load_model()

    # Predict
    prediction = model.predict(scaled_data)

    return prediction[0]

def main():
    parser = argparse.ArgumentParser(description='PC predictive maintenance tool.')
    parser.add_argument('--cpu', type=int, help='CPU usage threshold (default: 80)', default=80)
    parser.add_argument('--disk', type=int, help='Disk usage threshold (default: 20)', default=20)
    parser.add_argument('--memory', type=int, help='Memory usage threshold (default: 80)', default=80)
    parser.add_argument('--sender', type=str, help='Sender email address', required=True)
    parser.add_argument('--receiver', type=str, help='Receiver email address', required=True)
    parser.add_argument('--password', type=str, help='Email password', required=True)
    args = parser.parse_args()

    while True:
        # Collect data
        data = collect_data()

        # Preprocess data
        scaled_data = preprocess_data(data)

        # Predict failure
        prediction = predict_failure(scaled_data)

        # Check for failure
        if prediction == 1:
            subject = "PC component failure alert!"
            message = "One or more PC components are likely to fail. Check the PC for any issues."
            send_email(subject, message, args.sender, args.receiver, args.password)
        else:
            # Check for high CPU usage
            if check_cpu_usage(args.cpu):
                subject = "High CPU usage alert!"
                message = "CPU usage is over {}%. Check the PC for any issues.".format(args.cpu)
                send_email(subject, message, args.sender, args.receiver, args.password)

            # Check for low disk space
            if check_disk_usage(args.disk):
                subject = "Low disk space alert!"
                message = "Disk space is running low. Free up some space."
            send_email(subject, message, args.sender, args.receiver, args.password)
            
            # Collect historical data
            disk_usage_history = []
            for i in range(5):
                total, used, free = psutil.disk_usage("/")
                disk_usage_history.append((total, used, free))
                time.sleep(60)
            
            # Preprocess the historical data
            disk_usage_history = [(used / total) * 100 for total, used, free in disk_usage_history]
            disk_usage_history = [d / max(disk_usage_history) for d in disk_usage_history]
            disk_usage_history = [d if d < 1 else 1 for d in disk_usage_history]
            disk_usage_history = disk_usage_history[-20:]
            
            # Predict next disk usage
            next_disk_usage = model.predict([disk_usage_history])[0]
            next_disk_usage_percent = int(next_disk_usage * 100)
            
            # Send email notification about predicted low disk space
            if next_disk_usage > args.disk / 100:
                subject = "Low disk space predicted!"
                message = f"Disk space is predicted to be below {next_disk_usage_percent}%. Free up some space."
                send_email(subject, message, args.sender, args.receiver, args.password)
                
        # Check for high memory usage
        if check_memory_usage(args.memory):
            subject = "High memory usage alert!"
            message = "Memory usage is over {}%. Check the PC for any issues.".format(args.memory)
            send_email(subject, message, args.sender, args.receiver, args.password)
            
            # Collect historical data
            memory_usage_history = []
            for i in range(5):
                usage = psutil.virtual_memory().percent
                memory_usage_history.append(usage)
                time.sleep(60)
            
            # Preprocess the historical data
            memory_usage_history = [usage / 100 for usage in memory_usage_history]
            memory_usage_history = [d if d < 1 else 1 for d in memory_usage_history]
            memory_usage_history = memory_usage_history[-20:]
            
            # Predict next memory usage
            next_memory_usage = model.predict([memory_usage_history])[0]
            next_memory_usage_percent = int(next_memory_usage * 100)
            
            # Send email notification about predicted high memory usage
            if next_memory_usage > args.memory / 100:
                subject = "High memory usage predicted!"
                message = f"Memory usage is predicted to be over {next_memory_usage_percent}%. Check the PC for any issues."
                send_email(subject, message, args.sender, args.receiver, args.password)
                
        time.sleep(60*5) # Check every 5 minutes

