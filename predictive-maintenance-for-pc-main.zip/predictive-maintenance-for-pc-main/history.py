import psutil
import time
import csv

# Set the data collection interval
interval = 1 # seconds

# Open a CSV file to store the data
filename = 'data/historical_data.csv'
with open(filename, 'w', newline='') as csvfile:
    fieldnames = ['timestamp', 'cpu_percent', 'disk_usage', 'memory_percent', 'target']
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
    writer.writeheader()

    # Collect data at the specified interval and write it to the CSV file
    while True:
        # Get the current timestamp
        timestamp = int(time.time())

        # Get CPU usage as a percentage
        cpu_percent = psutil.cpu_percent()

        # Get disk usage as a percentage
        disk_usage = psutil.disk_usage('/').percent

        # Get memory usage as a percentage
        memory_percent = psutil.virtual_memory().percent

        # Get target value based on disk usage
        target = 1 if disk_usage > 90 else 0

        # Write the data to the CSV file
        writer.writerow({'timestamp': timestamp,
                         'cpu_percent': cpu_percent,
                         'disk_usage': disk_usage,
                         'memory_percent': memory_percent,
                         'target': target})
        csvfile.flush()

        # Wait for the next data collection interval
        time.sleep(interval)
