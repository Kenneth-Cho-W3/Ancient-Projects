# predictive-maintenance-for-pc
A simple program that use machine learning to monitor the health of a PC, including features such as monitoring the CPU and memory usage, notify users if the are issues for the PC.
