import ai.openai.completion.v1.CompletionServiceGrpc
import ai.openai.completion.v1.CompletionOuterClass
import io.grpc.ManagedChannel
import io.grpc.ManagedChannelBuilder
import java.io.File
import java.util.*

fun main() {
    // Set the file path for the API key
    val apiKeyFile = File("api_key.txt")

    // Read the API key from the file or prompt the user to enter it
    val apiKey = if (apiKeyFile.exists() && apiKeyFile.canRead()) {
        apiKeyFile.readText().trim()
    } else {
        println("API key not found or not readable.")
        println("Please enter your OpenAI API key:")
        val input = Scanner(System.`in`)
        val newApiKey = input.nextLine().trim()
        apiKeyFile.writeText(newApiKey)
        newApiKey
    }

    // Connect to the OpenAI API using gRPC
    val channel: ManagedChannel = ManagedChannelBuilder.forTarget("api.openai.com").useTransportSecurity().build()
    val stub: CompletionServiceGrpc.CompletionServiceBlockingStub = CompletionServiceGrpc.newBlockingStub(channel)

    // Generate text with the GPT-3 model
    val prompt = "Hello, I'm ChatGPT. How can I help you today?"
    val request = CompletionOuterClass.CreateCompletionRequest.newBuilder()
        .setModel("davinci")
        .setPrompt(prompt)
        .setMaxTokens(50)
        .setN(1)
        .build()
    val response = try {
        stub.createCompletion(request, io.grpc.Metadata().apply { put(io.grpc.Metadata.Key.of("authorization", io.grpc.Metadata.ASCII_STRING_MARSHALLER), "Bearer $apiKey") })
    } catch (e: io.grpc.StatusRuntimeException) {
        if (e.status.code == io.grpc.Status.Code.UNAUTHENTICATED) {
            println("Invalid API key. Please enter your OpenAI API key:")
            val input = Scanner(System.`in`)
            val newApiKey = input.nextLine().trim()
            apiKeyFile.writeText(newApiKey)
            stub.createCompletion(request, io.grpc.Metadata().apply { put(io.grpc.Metadata.Key.of("authorization", io.grpc.Metadata.ASCII_STRING_MARSHALLER), "Bearer $newApiKey") })
        } else {
            throw e
        }
    }

    // Print the generated text
    val text = response.choicesList[0].text
    println(text)

    // Shutdown the channel
    channel.shutdown()
}
