# OpenAI GPT-3 Text Generation with Kotlin

This is a Kotlin code sample that demonstrates how to generate text using OpenAI's GPT-3 language model via the OpenAI API. The code uses the gRPC protocol to communicate with the OpenAI API and requires an API key for authentication.
## Requirements

To run this code sample, you will need:

1. An OpenAI API key
2. Java Development Kit (JDK) version 8 or higher
3. Kotlin version 1.3.72 or higher
4. gRPC version 1.29.0 or higher

## Usage

- Clone or download the code to your local machine.
- Open the `/main.kt` file.
- Set the file path for the API key in the apiKeyFile variable.
- Run the code using a Kotlin compiler, such as kotlinc or an integrated development environment (IDE) that supports Kotlin.
- The code will prompt you to enter your OpenAI API key if it is not found or not readable. Enter your API key and press Enter.
- The code will connect to the OpenAI API using gRPC, generate text with the GPT-3 model, and print the generated text to the console.
- The gRPC channel will be shutdown automatically when the program exits.

## Customization

You can customize the text generation by modifying the prompt variable and the parameters of the CompletionOuterClass.CreateCompletionRequest.newBuilder() method. For example, you can change the GPT-3 model to use, the maximum number of tokens to generate, and the number of completions to generate.
Security Considerations

This code sample uses an OpenAI API key to authenticate with the OpenAI API. Therefore, it is important to keep the API key secure and not share it with unauthorized parties. It is recommended to store the API key in a file with restricted access permissions or in a secure storage system.
## License

This code sample is licensed under the Mozilla Public License. See the LICENSE file for more information.
