import argparse
import lzma
import tarfile
from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes

parser = argparse.ArgumentParser(description='Create a compressed archive of multiple files')
parser.add_argument('input_files', nargs='+', help='paths to the input files')
parser.add_argument('output_file', help='path to the output file')
parser.add_argument('-c', '--compression-level', type=int, default=6, choices=range(0, 10),
                    help='compression level (0-9, default=6)')
parser.add_argument('-p', '--password', type=str, default=None,
                    help='password to encrypt the archive')
parser.add_argument('-k', '--key-length', type=int, default=128, choices=[128, 256, 512],
                    help='encryption key length in bits (128, 256, or 512, default=128)')
args = parser.parse_args()

# Generate a random encryption key if no password is provided
if args.password is None:
    encryption_key = get_random_bytes(args.key_length // 8)
else:
    # Hash the password to create an encryption key
    encryption_key = AES.new(args.password.encode(), AES.MODE_EAX).digest()

# Create an encryption cipher with the key, if a password was provided
encryption_cipher = AES.new(encryption_key, AES.MODE_EAX) if args.password is not None else None

with lzma.open(args.output_file, 'wb', preset=args.compression_level) as f_out, \
        tarfile.open(mode='w:', fileobj=f_out) as tar:
    for input_file in args.input_files:
        if encryption_cipher is not None:
            # Encrypt each input file and add it to the tar archive
            with open(input_file, 'rb') as f_in:
                encrypted_data, tag = encryption_cipher.encrypt_and_digest(f_in.read())
                tarinfo = tarfile.TarInfo(name=input_file)
                tarinfo.size = len(encrypted_data)
                tarinfo.mtime = 0
                tarinfo.mode = 0o600
                tar.addfile(tarinfo, lzma.compress(encrypted_data))
        else:
            # No encryption; just add the file to the tar archive
            tar.add(input_file)

    if encryption_cipher is not None:
        # Write the encryption key to the end of the archive
        encryption_key_data = encryption_cipher.nonce + encryption_cipher.encrypt(encryption_key)
        key_tarinfo = tarfile.TarInfo(name='encryption_key')
        key_tarinfo.size = len(encryption_key_data)
        key_tarinfo.mtime = 0
        key_tarinfo.mode = 0o600
        tar.addfile(key_tarinfo, lzma.compress(encryption_key_data))

if encryption_cipher is not None:
    print(f'Archive created with encryption key length: {len(encryption_key)*8} bits')
