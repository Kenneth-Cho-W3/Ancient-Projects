import os
import sys
import subprocess
from PyQt6.QtWidgets import (
    QApplication, QDialog, QFileDialog, QHBoxLayout, QLabel, QLineEdit, QPushButton, QSlider, QVBoxLayout, QCheckBox,
    QComboBox, QMessageBox
)
from PyQt6.QtCore import Qt


class ArchiveEncryptorGui(QDialog):
    def __init__(self):
        super().__init__()

        # Create the widgets
        self.input_label = QLabel('Input Files:')
        self.input_edit = QLineEdit()
        self.input_button = QPushButton('Browse')
        self.input_button.clicked.connect(self.browse_input)
        self.output_label = QLabel('Output File:')
        self.output_edit = QLineEdit()
        self.output_button = QPushButton('Browse')
        self.output_button.clicked.connect(self.browse_output)
        self.password_label = QLabel('Password:')
        self.password_edit = QLineEdit()
        self.password_edit.setEchoMode(QLineEdit.EchoMode.Password)
        self.key_length_label = QLabel('Key Length:')
        self.key_length_combo = QComboBox()
        self.key_length_combo.addItems(['128 bits', '256 bits', '512 bits'])
        self.compress_label = QLabel('Compression Level:')
        self.compress_slider = QSlider(Qt.Orientation.Horizontal)
        self.compress_slider.setRange(0, 9)
        self.compress_slider.setValue(6)
        self.compress_slider.setTickInterval(1)
        self.compress_slider.setTickPosition(QSlider.TickPosition.TicksBelow)
        self.encrypt_checkbox = QCheckBox('Encrypt')
        self.encrypt_checkbox.stateChanged.connect(self.enable_password)

        # Create the buttons
        self.create_button = QPushButton('Create Archive')
        self.create_button.clicked.connect(self.create_archive)
        self.quit_button = QPushButton('Quit')
        self.quit_button.clicked.connect(self.close)

        # Create the layouts
        input_layout = QHBoxLayout()
        input_layout.addWidget(self.input_edit)
        input_layout.addWidget(self.input_button)
        output_layout = QHBoxLayout()
        output_layout.addWidget(self.output_edit)
        output_layout.addWidget(self.output_button)
        password_layout = QHBoxLayout()
        password_layout.addWidget(self.password_edit)
        key_length_layout = QHBoxLayout()
        key_length_layout.addWidget(self.key_length_label)
        key_length_layout.addWidget(self.key_length_combo)
        compress_layout = QHBoxLayout()
        compress_layout.addWidget(self.compress_label)
        compress_layout.addWidget(self.compress_slider)
        checkbox_layout = QHBoxLayout()
        checkbox_layout.addWidget(self.encrypt_checkbox)
        button_layout = QHBoxLayout()
        button_layout.addWidget(self.create_button)
        button_layout.addWidget(self.quit_button)
        main_layout = QVBoxLayout()
        main_layout.addWidget(self.input_label)
        main_layout.addLayout(input_layout)
        main_layout.addWidget(self.output_label)
        main_layout.addLayout(output_layout)
        main_layout.addWidget(self.password_label)
        main_layout.addLayout(password_layout)
        main_layout.addLayout(key_length_layout)
        main_layout.addLayout(compress_layout)
        main_layout.addLayout(checkbox_layout)
        main_layout.addLayout(button_layout)
        self.setLayout(main_layout)

        # Set window properties
        self.setWindowTitle('Archive Encryptor')
        self.setFixedSize(500, 300)

    def browse_input(self):
        file_dialog = QFileDialog()
        file_dialog.setFileMode(QFileDialog.FileMode.ExistingFiles)
        if file_dialog.exec():
            file_names = file_dialog.selectedFiles()
            self.input_edit.setText(' '.join(file_names))

    def browse_output(self):
        file_dialog = QFileDialog()
        file_dialog.setFileMode(QFileDialog.FileMode.AnyFile)
        file_dialog.setAcceptMode(QFileDialog.AcceptMode.Save)
        file_dialog.setDefaultSuffix('tar.xz')
        if file_dialog.exec():
            file_name = file_dialog.selectedFiles()[0]
            self.output_edit.setText(file_name)

    def enable_password(self, state):
        self.password_edit.setEnabled(state)

    def create_archive(self):
        input_files = self.input_edit.text().split()
        output_file = self.output_edit.text()
        password = self.password_edit.text() if self.encrypt_checkbox.isChecked() else None
        key_length = self.key_length_combo.currentText()
        compress_level = str(self.compress_slider.value())

        # Convert key length to bits
        if key_length == '128 bits':
            key_length_bits = '128'
        elif key_length == '256 bits':
            key_length_bits = '256'
        elif key_length == '512 bits':
            key_length_bits = '512'

        # Build the command
        command = ['python', 'main.py', *input_files, output_file, '-c', compress_level]
        if password:
            command += ['-p', password, '-k', key_length_bits]

        # Run the command
        try:
            subprocess.run(command, check=True)
        except subprocess.CalledProcessError as e:
            QMessageBox.critical(self, 'Error', f'An error occurred: {e}', QMessageBox.StandardButton.Ok)
        else:
            QMessageBox.information(self, 'Success', 'Archive created successfully!', QMessageBox.StandardButton.Ok)
            self.close()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    gui = ArchiveEncryptorGui()
    gui.show()
    sys.exit(app.exec())
